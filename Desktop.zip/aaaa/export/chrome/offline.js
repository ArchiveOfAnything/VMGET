﻿{
	"version": 1641569650,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"c2webappstart.js",
		"images/2550f6d5143f87744011918374c09adc-sheet0.png",
		"images/3f3f3f3f3f3f3fsheet-sheet0.png",
		"images/p_o-sheet0.png",
		"images/spritefont.png",
		"images/sprite-sheet0.png",
		"images/sprite2-sheet0.png",
		"images/sprite3-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}