CREDITS
====================================================
Original Mod: https://www.youtube.com/channel/UCo73otjWRpvgdmqUlkJ-gQA
Lobby Map: https://www.youtube.com/channel/UCBAe23pOU5kr7SH6baCqS0w
Server DLL: Discord- Arthurdead#8326
Putting everything else together (and writing the readme): guyman70718#4884, u/guyman70718

HELP
====================================================
You will need:
 - 2-33 players
 - Hamachi or similar/port fowarding
 - Portal 2
 - Someone with Windows to host. If you are on mac, you can join, but not host a game.
 - To set up hamachi, watch this video: https://www.youtube.com/watch?v=95-4pEoxM7Y
	(you can spread out the people across multiple hamachi networks, just make sure everyone
	shares a network with the host. They don't have to share a network with each other)
Installing:
 - Go to "C:\Program Files (x86)\Steam\steamapps\common\Portal 2" and put the contents of this folder in there.


HOSTING:
 1. Open the COOP.cmd
 2. Press 2
 3. LAN server means only people in your house can join the game. (hamachi not needed)
 4. wait for the blue screen with the blueprints animation.
 5. Tell all your friends to connect, preferably around the same time.

JOINING: 
 1. Open Portal 2 
 2. Open the developer console by pressing "~" (you may need to enable this in options)
 3. Find the host's Hamachi IP by right clicking their name and clicking "Copy IPv4 Adress"
 4. In the developer console, type "connect <IPv4 adress here>" and wait for all the
	others to do the same. 
 5. Once everyone is ready, press enter at the same time.