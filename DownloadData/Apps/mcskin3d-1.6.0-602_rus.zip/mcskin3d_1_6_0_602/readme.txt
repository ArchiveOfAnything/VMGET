Welcome to MCSkin3D, the most awesome skinning experience since.. I have no puns at this time, it's 8:39 AM and I want to get this released because you people deserve it after like 6 months of waiting.

Forward any issues to paril@alteredsoftworks.com, drop a message at www.alteredsoftworks.com, or check the main forum posts:
- http://www.minecraftforum.net/topic/746941-mcskin3d-new-skinning-program/
