import ctypes, os
#import sys

'''
def restartAsAdmin():
    cnt = 0
    args_str = ""
    run_str = ""
    for arg in sys.argv:
        #if cnt >= 1:
            if cnt < len(sys.argv)-1:
                args_str += "\""+arg+"\", "
            else:
                args_str += "\""+arg+"\""
            cnt += 1
    
'''    
    
####    os.execv(sys.executable, ['python'] + sys.argv)

def isAdmin():   #info=#info=#info=/
    try:
       is_admin = os.getuid() == 0
    except AttributeError:
       is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0

    return is_admin    

    ###print (is_admin)