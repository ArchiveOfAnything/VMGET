def toFileName(text, replaceWith=None):
    if replaceWith != None:
        return text.replace(":", replaceWith).replace("\\", replaceWith).replace("/", replaceWith).replace("\"", replaceWith).replace("?", replaceWith).replace("<", replaceWith).replace(">", replaceWith).replace("*", replaceWith).replace("|", replaceWith)
    else:
        return text.replace(":", "_").replace("\\", "_").replace("/", "_").replace("\"", "_").replace("?", "_").replace("<", "_").replace(">", "_").replace("*", "_").replace("|", "_")        

def removeSpaces(text, replaceWith=None):
    if replaceWith != None:
        return text.replace(" ", replaceWith)
    else:
        return text.replace(" ", "")	
	
def	shttxt(text, replaceWith=None):
    if  replaceWith != None:
        return removeSpaces(toFileName(text, replaceWith), replaceWith)
    else:    
        return removeSpaces(toFileName(text))